/**Nota: Estive com duvidas na execucao do exercicio visto que foi pedido para mostrar a data nos dois formatos mas no cabecalho 
 * do metodo printDate no enuciado foi indicado que pedisse o formato no input. Por via das duvidas, resolvi modificar o metodo 
 * printDate para que ao inves do usuario escolher o formato para o output, os dois formatos seriam printados na tela.**/

import java.util.Scanner;

public class Ex_2_1 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Dia da semana: ");
        String diaSemana = scanner.next();
        System.out.print("Dia: ");
        int dia = scanner.nextInt();
        System.out.print("Mes: ");
        int mes = scanner.nextInt();
        System.out.print("Ano: ");
        int ano = scanner.nextInt();
        scanner.close();


        printDate(diaSemana, dia, mes, ano);

        
    }
    
    public static void printDate(String diaSemana, int dia, int mes, int ano){
        System.out.println("Formato CV: " + diaSemana + " " + dia + ", de " + convertMes(mes) + " de " + ano);
        System.out.println("Formato US: " + diaSemana + ", " + convertMes(mes) + " " + dia + ", " + ano);
        
    } 

    public static String convertMes(int mes){
        String op = " ";

        switch (mes) {
            case 1: op = "Janeiro";
                break;
            case 2: op = "Fevereiro";
                break;
            case 3: op = "Marco";
                break;
            case 4: op = "Abril";
                break;
            case 5: op = "Maio";
                break;
            case 6: op = "Junho";
                break;
            case 7: op = "julho";
                break;
            case 8: op = "Agosto";
                break;
            case 9: op = "Setembo";
                break;
            case 10: op = "Outubro";
                break;
            case 11: op = "Novembro";
                break;
            case 12: op = "Dezembro";
                break;
            default:
                System.out.println("Nao e um mes!");
                break;
        }

        return op;
    } 
}