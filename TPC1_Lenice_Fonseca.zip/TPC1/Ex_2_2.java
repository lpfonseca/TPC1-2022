import java.util.Scanner;

public class Ex_2_2 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("x1: ");
        int x1 = scanner.nextInt();
        System.out.print("y1: ");
        int y1 = scanner.nextInt();
        System.out.print("x2: ");
        int x2 = scanner.nextInt();
        System.out.print("y2: ");
        int y2 = scanner.nextInt();
        scanner.close();

        System.out.println("Distancia: " + distanciaDePontos(x1, y1, x2, y2));
        
    }

    public static float distanciaDePontos(int x1, int y1, int x2, int y2){
        float distancia = 0;
        float x = x2 - x1;
        float y = y2 - y1;

        distancia = (float) Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));

        return distancia;
    }


}
