import java.time.LocalDate;
import java.util.Scanner;

public class Ex_2_4 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int ano;
        int mes;
        int dia;

        System.out.print("Dia: ");
        dia = scanner.nextInt();
        System.out.print("Mes: ");
        mes = scanner.nextInt();
        System.out.print("Ano: ");
        ano = scanner.nextInt();
        scanner.close();
        
        System.out.println();
        System.out.println("Bissexto? " + eBissexto(ano));
        System.out.println();
        System.out.println("Formato aaaa-mm-dd");
        printDataDias(dia, mes, ano);
        
    }

    public static boolean eBissexto(int ano){
        if(ano % 400 == 0){
            return true;
        } else if((ano % 4 == 0) && (ano % 100 != 0)){
            return true;
        } else{
            return false;
        }
    }

    public static void printDataDias(int dia, int mes, int ano) {
        LocalDate dataAnt = LocalDate.of(ano, mes, dia);
        LocalDate dataSeg = LocalDate.of(ano, mes, dia);

        dataAnt = dataAnt.minusDays(1);
        dataSeg = dataSeg.plusDays(1);
        
        System.out.println("Data seguinte: " + dataSeg);
        System.out.println("Data anterior: " + dataAnt);
    }
}
