/**Nota: Adicionei parametros ao metodo calcularAngulo, visto que nao seria possivel obter o resultado se nao houvesse
 * dados de entrada**/

import java.util.Scanner;

public class Ex_2_3 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Cateto A: ");
        double catetoA = scanner.nextDouble();
        System.out.print("Cateto B: ");
        double catetoB = scanner.nextDouble();
        scanner.close();

        double degrees = Math.toDegrees(calcularAngulo(catetoA, calcularHipotenusa(catetoA, catetoB)));

        System.out.println("Hipotenusa = " + calcularHipotenusa(catetoA, catetoB));
        System.out.println("Angulo = " + degrees + " graus");
        
    }

    public static double calcularHipotenusa(double catetoA, double catetoB){
        float hipotenusa = 0;
        hipotenusa = (float) Math.sqrt(Math.pow(catetoA, 2) + Math.pow(catetoB, 2));
        return hipotenusa;
    }

    public static double calcularAngulo(double catetoA, Double hipotenusa) {
        return Math.cos(catetoA/hipotenusa);
    }


}
