import java.util.Scanner;

public class Triangle {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Lado A: ");
        int a = scanner.nextInt();
        System.out.print("Lado B: ");
        int b = scanner.nextInt();
        System.out.print("Lado C: ");
        int c = scanner.nextInt();
        scanner.close();

        if (!testeTriangulo(a, b, c)) {
            System.out.println("Nao e possivel formar um triangulo!");
        }
        else{
            System.out.println("Possivel formar um triangulo!");
        }      
        
    }

    public static boolean testeTriangulo(int a, int b, int c) {
        if (a > b+c) {
            return false;
        }
        else if (b > a+c) {
            return false;
        }
        else if (c > a+b) {
            return false;
        }
        else {
            return true;
        }
        
    }
}
