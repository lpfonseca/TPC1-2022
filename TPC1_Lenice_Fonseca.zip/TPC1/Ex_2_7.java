import java.util.Scanner;

public class Ex_2_7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Valor de a: ");
        int a = scanner.nextInt();
        System.out.print("Valor de b: ");
        int b = scanner.nextInt();
        System.out.print("Valor de c: ");
        int c = scanner.nextInt();
        scanner.close();

        if (a != 0) {
            calcularRaizes(a, b, c);
        }
        else {
            System.out.println("O valor de a tem de ssr diferente de 0!");
        }
    }

    public static void calcularRaizes(int a, int b, int c) {
        double delta = Math.pow(b, 2) - (4*a*c);
        double raizDelta = Math.sqrt(delta);

        if (delta > 0) {
            double raiz1 = ((-1)*b + raizDelta)/(2*a);
            double raiz2 = ((-1)*b - raizDelta)/(2*a);
            System.out.println("Raiz 1: " + raiz1);
            System.out.println("Raiz 2: " + raiz2);
        }
        else {
            System.out.println("Impossivel!");
        }
    }
}
